/*------------------------------------------------------------------------*/
/*  Wmrpnobj.h                                                            */
/*  Copyright (c) 1991                                                    */
/*  W.M. Mooij                                                            */
/*  Kluiskenslaan 21                                                      */
/*  2082 GT  Santpoort Zuid                                               */
/*  The Netherlands                                                       */
/*  All Rights Reserved                                                   */
/*------------------------------------------------------------------------*/

#ifndef __WMRPNOBJ_H
#define __WMRPNOBJ_H

#include "wmwmmobj.h"

// Class definitions

#endif

/*------------------------------------------------------------------------*/
/*  Wmbinobj.h                                                            */
/*  Copyright (c) 1991                                                    */
/*  W.M. Mooij                                                            */
/*  Kluiskenslaan 21                                                      */
/*  2082 GT  Santpoort Zuid                                               */
/*  The Netherlands                                                       */
/*  All Rights Reserved                                                   */
/*------------------------------------------------------------------------*/

#ifndef __WMBINOBJ_H
#define __WMBINOBJ_H

#include "wmwmmobj.h"

// Class definitions

#endif

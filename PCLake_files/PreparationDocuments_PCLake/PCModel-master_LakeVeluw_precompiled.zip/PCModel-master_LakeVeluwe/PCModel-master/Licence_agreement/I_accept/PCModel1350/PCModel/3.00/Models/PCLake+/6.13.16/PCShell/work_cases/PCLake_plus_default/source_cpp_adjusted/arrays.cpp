static double auxil[2477];
static double initAuxil[186];
static double param[601];
static double state[134];
